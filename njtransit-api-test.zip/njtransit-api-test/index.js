import { TrainDocumentProcessor } from './src/processors/trainProcessor.js';
import { AlertService } from './src/services/alertService.js';
import { CONFIG } from './src/config/config.js';
import { writeFile } from 'fs/promises';
import path from 'path';
import fs from 'fs/promises';

// Handle document updates
const handleDocumentUpdate = async (document) => {
  console.log('\n=== System Update Received ===');
  console.log('Timestamp:', document.timestamp);
  console.log('Active Trains:', document.trains?.length || 0);
  console.log('Total Stations:', document.stations?.length || 0);

  // Set the file directory
  const dataDir = path.join('C:', 'Users', 'mjone', 'njtransit-api-test', 'data');

  // Save the data to a JSON file
  try {
    await fs.mkdir(dataDir, { recursive: true });
    const dataFilePath = path.join(dataDir, 'train-data.json');
    await writeFile(dataFilePath, JSON.stringify(document, null, 2));
    console.log('Saved data to', dataFilePath);
  } catch (error) {
    console.error('Error saving data:', error);
  }

  // Log sample train and station data if available
  if (document.trains?.length > 0) {
    console.log('\nSample Train Data:');
    const sampleTrain = document.trains[0];
    console.log({
      trainId: sampleTrain.trainId,
      line: sampleTrain.line,
      status: sampleTrain.status,
      location: sampleTrain.currentStatus?.location,
      nextStop: sampleTrain.currentStatus?.movement?.nextStop
    });
  }

  if (document.stations?.length > 0) {
    console.log('\nSample Station Data:');
    const sampleStation = document.stations[0];
    console.log({
      name: sampleStation.name,
      code: sampleStation.code,
      line: sampleStation.line,
      location: sampleStation.location,
      accessibility: sampleStation.accessibility,
      schedule: sampleStation.schedule
    });
  }
};

// Handle errors
const handleError = (error) => {
  console.error('System Error:', error);
};

// Create services
const trainProcessor = new TrainDocumentProcessor(handleDocumentUpdate, handleError);
const alertService = new AlertService();

// Start processing
console.log('Starting NJ Transit train tracking system...');
trainProcessor.start();

// Fetch alerts periodically
setInterval(async () => {
  try {
    const alerts = await alertService.fetchAlerts();
    console.log(`Fetched ${alerts.length} alerts`);
  } catch (error) {
    console.error('Error fetching alerts:', error);
  }
}, 60000); // Check alerts every minute

// Handle application shutdown
process.on('SIGINT', () => {
  console.log('\nShutting down...');
  trainProcessor.stop();
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('\nShutting down...');
  trainProcessor.stop();
  process.exit(0);
});