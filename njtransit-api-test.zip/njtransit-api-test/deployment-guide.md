# NJ Transit API Integration - OCI Linux Deployment Guide

## Prerequisites
- Linux server on OCI with SSH access
- Node.js 18+ installed
- Git installed
- PM2 or similar process manager for Node.js applications
- Nginx (optional, for reverse proxy)
- SSL certificate (recommended for production)

## 1. Server Setup

### Update System
```bash
sudo apt update
sudo apt upgrade -y
```

### Install Node.js (if not installed)
```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Verify installation
node --version
[opc@coco-butta ~]$ node --version
v18.20.4


npm --version
[opc@coco-butta ~]$ npm --version
10.7.0
```

### Install PM2 globally
```bash
sudo npm install -g pm2
```

## 2. Application Setup

### Create Application Directory
```bash
mkdir -p /opt/njtransit
cd /opt/njtransit
```

### Clone Repository
```bash
git clone [your-repository-url] .
```

### Install Dependencies
```bash
npm install
```

### Configure Environment
1. Create environment file:
```bash
cp config.js .env
```

2. Edit the environment file with your production values:
```bash
nano .env
```

Add the following (adjust values as needed):
```
NODE_ENV=production
PORT=3000
NJT_USERNAME=your_username
NJT_PASSWORD=your_password
```

## 3. Security Considerations

### File Permissions
```bash
# Set ownership
sudo chown -R nodejs:nodejs /opt/njtransit

# Set directory permissions
sudo chmod 755 /opt/njtransit

# Set config file permissions
sudo chmod 600 /opt/njtransit/.env
```

### Firewall Rules
```bash
# Allow SSH
sudo ufw allow ssh

# Allow HTTP/HTTPS if needed
sudo ufw allow 80
sudo ufw allow 443

# Allow specific application port if needed
sudo ufw allow 3000

# Enable firewall
sudo ufw enable
```

## 4. Application Deployment

### Create PM2 Configuration
Create ecosystem.config.js:
```javascript
module.exports = {
  apps: [{
    name: 'njtransit-api',
    script: 'index.js',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    }
  }]
};
```

### Start Application
```bash
# Start the application
pm2 start ecosystem.config.js

# Save PM2 configuration
pm2 save

# Setup PM2 startup script
pm2 startup
```

## 5. (Optional) Nginx Setup

### Install Nginx
```bash
sudo apt install nginx
```

### Configure Nginx
Create configuration file:
```bash
sudo nano /etc/nginx/sites-available/njtransit
```

Add the following configuration:
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable the site:
```bash
sudo ln -s /etc/nginx/sites-available/njtransit /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

## 6. Monitoring and Logging

### View Logs
```bash
# View PM2 logs
pm2 logs njtransit-api

# View specific number of lines
pm2 logs njtransit-api --lines 100
```

### Monitor Application
```bash
# Monitor processes
pm2 monit

# List processes
pm2 list
```

## 7. Backup and Maintenance

### Setup Automated Backups
```bash
# Create backup script
nano /opt/njtransit/backup.sh
```

Add backup logic:
```bash
#!/bin/bash
BACKUP_DIR="/backup/njtransit"
DATE=$(date +%Y%m%d)
mkdir -p $BACKUP_DIR
tar -czf $BACKUP_DIR/njtransit_$DATE.tar.gz /opt/njtransit
```

Make script executable:
```bash
chmod +x /opt/njtransit/backup.sh
```

Add to crontab:
```bash
crontab -e
# Add line:
0 0 * * * /opt/njtransit/backup.sh
```

## 8. Testing

After deployment, test the following:
1. API endpoint accessibility
2. Authentication with NJ Transit APIs
3. Real-time data updates
4. Error handling and logging
5. Monitoring alerts
6. Backup processes

## 9. Troubleshooting

Common issues and solutions:
1. **API Connection Issues**: Check NJ Transit API credentials and network connectivity
2. **Memory Issues**: Monitor with `pm2 monit` and adjust `max_memory_restart` if needed
3. **Permission Issues**: Verify file ownership and permissions
4. **Port Conflicts**: Check if port 3000 is available or configure different port

## 10. Maintenance Tasks

Regular maintenance checklist:
- [ ] Check application logs for errors
- [ ] Monitor system resources
- [ ] Verify backup integrity
- [ ] Update Node.js dependencies
- [ ] Rotate logs
- [ ] Check SSL certificate expiration (if applicable)
