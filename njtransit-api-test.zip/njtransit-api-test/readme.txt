# NJ Transit API Aggregator

A comprehensive API aggregator for NJ Transit train data, combining:
- Real-time train tracking
- Station proximity search
- Service alerts and advisories
- Schedule information

## Features
- Combined data from multiple NJ Transit APIs
- Geolocation-based station search
- Real-time train status updates
- Service alerts integration
- Departure board views

## Project Structure
```
njtransit-api-aggregator/
├── src/
│   ├── config/           # Configuration files
│   ├── services/         # Core services
│   ├── processors/       # Data processors
│   └── utils/           # Utility functions
├── tests/
│   ├── integration/     # Integration tests
│   └── unit/           # Unit tests
└── docs/               # Documentation
```

## Getting Started

1. Install dependencies:
```bash
npm install
```

2. Configure environment variables:
```bash
cp .env.example .env
# Edit .env with your credentials
```

3. Run tests:
```bash
npm test
```

4. Start the service:
```bash
npm start
```

## API Documentation

### Location-Based Station Search
```javascript
GET /api/stations/nearby
Parameters:
  - latitude: number
  - longitude: number
  - radius: number (km)
```

### Station Schedules
```javascript
GET /api/stations/:stationId/schedule
```

### Train Status
```javascript
GET /api/trains/:trainId
```

## Data Sources
- NJ Transit Train Data API
- NJ Transit Alerts RSS Feed
- Station Geolocation Data

## Contributing
See CONTRIBUTING.md for details on our code of conduct and the process for submitting pull requests.

## License
This project is licensed under the MIT License - see LICENSE.md for details.
