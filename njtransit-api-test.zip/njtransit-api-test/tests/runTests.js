import { testVehicleDataFetch } from './integration/vehicle-test.js';
import { testScheduleDataFetch } from './integration/schedule-test.js';
import { testStopDataFetch } from './integration/stop-test.js';

async function runAllTests() {
  try {
    console.log('Starting API integration tests...\n');

    console.log('=== Vehicle Data Tests ===');
    await testVehicleDataFetch();
    console.log('\n');

    console.log('=== Schedule Data Tests ===');
    await testScheduleDataFetch();
    console.log('\n');

    console.log('=== Stop Data Tests ===');
    await testStopDataFetch();
    console.log('\n');

    console.log('All tests completed successfully!');
  } catch (error) {
    console.error('Test suite failed:', error);
    process.exit(1);
  }
}

// Run all tests
runAllTests()
  .then(() => process.exit(0))
  .catch(error => {
    console.error('Tests failed:', error);
    process.exit(1);
  });
