import { TrainDocumentProcessor } from '../../src/processors/trainProcessor.js';

// Sample test data matching actual API responses
const sampleVehicleData = [
  {
    "ID": "3248",
    "TRAIN_LINE": "NJCL",
    "DIRECTION": "Westbound",
    "ICS_TRACK_CKT": "",
    "LAST_MODIFIED": "19-May-2023 01:57:30 PM",
    "SCHED_DEP_TIME": "19-May-2023 02:11:00 PM",
    "SEC_LATE": "50",
    "NEXT_STOP": "Newark Penn",
    "LONGITUDE": "-74.1907170000",
    "LATITUDE": "40.7044150000"
  }
];

const sampleScheduleData = {
  "STATION_2CHAR": "NP",
  "STATIONNAME": "Newark Penn",
  "STATIONMSGS": [],
  "ITEMS": [
    {
      "SCHED_DEP_DATE": "19-May-2023 02:11:00 PM",
      "DESTINATION": "New York -SEC",
      "TRACK": "1",
      "LINE": "NJCL",
      "TRAIN_ID": "3248",
      "STATUS": "in 2 Min",
      "SEC_LATE": "50",
      "LAST_MODIFIED": "19-May-2023 02:09:29 PM",
      "BACKCOLOR": "black",
      "FORECOLOR": "white",
      "SHADOWCOLOR": "",
      "GPSLATITUDE": "",
      "GPSLONGITUDE": "",
      "GPSTIME": "19-May-2023 02:09:27 PM",
      "STATION_POSITION": "1",
      "LINECODE": "NC",
      "LINEABBREVIATION": "NJCL",
      "INLINEMSG": ""
    }
  ]
};

const sampleStopData = {
  "TRAIN_ID": "3248",
  "LINECODE": "NC",
  "BACKCOLOR": "#F7505E",
  "FORECOLOR": "white",
  "SHADOWCOLOR": "black",
  "DESTINATION": "New York",
  "TRANSFERAT": "",
  "STOPS": [
    {
      "STATION_2CHAR": "NP",
      "STATIONNAME": "Newark Penn Station",
      "TIME": "19-May-2023 02:10:20 PM",
      "PICKUP": "",
      "DROPOFF": "",
      "DEPARTED": "NO",
      "STOP_STATUS": "OnTime",
      "DEP_TIME": "19-May-2023 02:11:00 PM",
      "STOP_LINES": []
    }
  ]
};

async function testDataTransforms() {
  const processor = new TrainDocumentProcessor(() => {}, console.error);
  
  console.log('\n=== Testing Data Transformations ===');

  try {
    // Test vehicle data processing
    console.log('\nTesting Vehicle Data Processing:');
    const processedVehicles = processor.processVehicleData(sampleVehicleData);
    console.log('Processed Vehicle Data:', JSON.stringify(processedVehicles[0], null, 2));

    // Verify vehicle data structure
    const vehicleTests = {
      'has trainId': processedVehicles[0].trainId === '3248',
      'has line': processedVehicles[0].line === 'NJCL',
      'has location data': processedVehicles[0].currentStatus.location.latitude && 
                         processedVehicles[0].currentStatus.location.longitude,
      'has movement data': processedVehicles[0].currentStatus.movement.direction && 
                         processedVehicles[0].currentStatus.movement.nextStop
    };

    console.log('\nVehicle Data Tests:', vehicleTests);

    // Test schedule data processing
    console.log('\nTesting Schedule Data Processing:');
    const processedSchedules = processor.processScheduleData(sampleScheduleData);
    console.log('Processed Schedule Data:', JSON.stringify(processedSchedules[0], null, 2));

    // Verify schedule data structure
    const scheduleTests = {
      'has trainId': processedSchedules[0].trainId === '3248',
      'has destination': processedSchedules[0].destination === 'New York -SEC',
      'has track': processedSchedules[0].track === '1',
      'has line info': processedSchedules[0].line.name === 'NJCL',
      'has status': processedSchedules[0].status.current === 'in 2 Min'
    };

    console.log('\nSchedule Data Tests:', scheduleTests);

    // Test stop list processing
    console.log('\nTesting Stop List Processing:');
    const processedStops = processor.processStopList(sampleStopData);
    console.log('Processed Stop Data:', JSON.stringify(processedStops, null, 2));

    // Verify stop list structure
    const stopTests = {
      'has trainId': processedStops.trainId === '3248',
      'has line code': processedStops.line.code === 'NC',
      'has stops array': Array.isArray(processedStops.stops),
      'has station info': processedStops.stops[0].station.code === 'NP',
      'has timing info': processedStops.stops[0].times.scheduled && 
                        processedStops.stops[0].times.departure
    };

    console.log('\nStop List Tests:', stopTests);

    // Return all test results
    return {
      vehicleTests,
      scheduleTests,
      stopTests
    };
  } catch (error) {
    console.error('Data transformation test failed:', error);
    throw error;
  }
}

// Run test
console.log('=== Running Data Transform Tests ===\n');
testDataTransforms()
  .then(results => {
    console.log('\nAll transformation tests completed');
    console.log('Test Results:', results);
    
    // Check if all tests passed
    const allTestsPassed = Object.values(results).every(
      testGroup => Object.values(testGroup).every(test => test)
    );
    
    if (allTestsPassed) {
      console.log('\nAll tests passed successfully!');
      process.exit(0);
    } else {
      console.error('\nSome tests failed!');
      process.exit(1);
    }
  })
  .catch(error => {
    console.error('Tests failed:', error);
    process.exit(1);
  });
