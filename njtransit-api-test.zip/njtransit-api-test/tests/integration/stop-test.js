import { TrainDocumentProcessor } from '../../src/processors/trainProcessor.js';

async function testStopDataFetch() {
  console.log('Starting stop data test...');
  const processor = new TrainDocumentProcessor(
    (data) => console.log('Data received:', data),
    (error) => console.error('Error:', error)
  );
  
  try {
    // First get a train ID from vehicle data
    console.log('\nFetching vehicle data to get train IDs...');
    const vehicleData = await processor.fetchVehicleData();
    
    if (vehicleData.length === 0) {
      console.log('No active trains found');
      return null;
    }

    const trainId = vehicleData[0].ID;
    console.log(`\nFetching stop data for train: ${trainId}`);
    
    const stopData = await processor.fetchTrainStops(trainId);
    
    console.log('\n=== Stop Data Results ===');
    console.log('Train:', stopData.TRAIN_ID);
    console.log('Line:', stopData.LINECODE);
    console.log('Destination:', stopData.DESTINATION);
    console.log('Number of stops:', stopData.STOPS?.length || 0);
    
    if (stopData.STOPS?.length > 0) {
      console.log('\nSample Stop:');
      const sampleStop = stopData.STOPS[0];
      console.log({
        station: sampleStop.STATIONNAME,
        time: sampleStop.TIME,
        status: sampleStop.STOP_STATUS,
        departed: sampleStop.DEPARTED
      });
    }

    return stopData;
  } catch (error) {
    console.error('Stop data fetch failed:', error);
    throw error;
  }
}

// Run test
console.log('=== Running Stop Data Test ===\n');
testStopDataFetch()
  .then(() => {
    console.log('\nStop data test completed successfully');
    process.exit(0);
  })
  .catch(error => {
    console.error('Test failed:', error);
    process.exit(1);
  });
