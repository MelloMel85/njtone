import { LocationService } from '../../src/services/locationService.js';
import { TrainDocumentProcessor } from '../../src/processors/trainProcessor.js';
import { AlertService } from '../../src/services/alertService.js';

async function testLocationService() {
  console.log('Starting location service test...');
  
  const locationService = new LocationService();
  const trainProcessor = new TrainDocumentProcessor();
  const alertService = new AlertService();

  try {
    // Test coordinates (New York Penn Station area)
    const testLat = 40.750046;
    const testLon = -73.992358;
    const radius = 5; // 5km radius

    console.log(`\nSearching for stations within ${radius}km of (${testLat}, ${testLon})`);
    
    // Find nearby stations
    const nearbyStations = locationService.findStationsInRadius(testLat, testLon, radius);
    
    console.log(`\nFound ${nearbyStations.length} stations within radius`);

    // Get detailed information for the closest 3 stations
    const detailedStations = await Promise.all(
      nearbyStations.slice(0, 3).map(async station => {
        const details = await locationService.getStationDetails(
          station.PENTA_ID,
          trainProcessor,
          alertService
        );

        return {
          station: station.STATIONNAME,
          distance: station.distance.toFixed(2) + ' km',
          nextTrains: details.schedule.ITEMS?.slice(0, 3).map(train => ({
            trainId: train.TRAIN_ID,
            destination: train.DESTINATION,
            departure: train.SCHED_DEP_DATE,
            track: train.TRACK,
            status: train.STATUS
          })),
          alerts: details.alerts
        };
      })
    );

    console.log('\n=== Nearest Stations ===');
    detailedStations.forEach(station => {
      console.log(`\n${station.station} (${station.distance})`);
      
      if (station.nextTrains?.length > 0) {
        console.log('Next Trains:');
        station.nextTrains.forEach(train => 
          console.log(`- ${train.trainId} to ${train.destination} at ${train.departure} (Track ${train.track})`));
      }
      
      if (station.alerts?.length > 0) {
        console.log('Alerts:');
        station.alerts.forEach(alert => 
          console.log(`- ${alert.title}`));
      }
    });

    return detailedStations;
  } catch (error) {
    console.error('Location service test failed:', error);
    throw error;
  }
}

// Run test
console.log('=== Running Location Service Test ===\n');
testLocationService()
  .then(() => {
    console.log('\nLocation service test completed successfully');
    process.exit(0);
  })
  .catch(error => {
    console.error('Test failed:', error);
    process.exit(1);
  });
