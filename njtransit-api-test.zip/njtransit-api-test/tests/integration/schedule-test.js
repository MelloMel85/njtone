import { TrainDocumentProcessor } from '../../src/processors/trainProcessor.js';

async function testScheduleDataFetch() {
  console.log('Starting schedule data test...');
  const processor = new TrainDocumentProcessor(
    (data) => console.log('Data received:', data),
    (error) => console.error('Error:', error)
  );
  
  try {
    console.log('\nFetching schedule for Newark Penn Station (NP)...');
    const scheduleData = await processor.fetchStationSchedule('NP');
    
    console.log('\n=== Schedule Data Results ===');
    console.log('Station:', scheduleData.STATIONNAME);
    console.log('Number of trains:', scheduleData.ITEMS?.length || 0);
    console.log('Has messages:', scheduleData.STATIONMSGS?.length > 0);
    
    if (scheduleData.ITEMS?.length > 0) {
      console.log('\nSample Train Schedule:');
      const sampleTrain = scheduleData.ITEMS[0];
      console.log({
        trainId: sampleTrain.TRAIN_ID,
        destination: sampleTrain.DESTINATION,
        line: sampleTrain.LINE,
        track: sampleTrain.TRACK,
        scheduledDeparture: sampleTrain.SCHED_DEP_DATE,
        status: sampleTrain.STATUS
      });
    }

    return scheduleData;
  } catch (error) {
    console.error('Schedule data fetch failed:', error);
    throw error;
  }
}

// Run test
console.log('=== Running Schedule Data Test ===\n');
testScheduleDataFetch()
  .then(() => {
    console.log('\nSchedule data test completed successfully');
    process.exit(0);
  })
  .catch(error => {
    console.error('Test failed:', error);
    process.exit(1);
  });