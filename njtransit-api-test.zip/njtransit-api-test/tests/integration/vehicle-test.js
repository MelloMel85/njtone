import { TrainDocumentProcessor } from '../../src/processors/trainProcessor.js';

async function testVehicleDataFetch() {
  console.log('Starting vehicle data test...');
  const processor = new TrainDocumentProcessor(
    (data) => console.log('Data received:', data),
    (error) => console.error('Error:', error)
  );
  
  try {
    console.log('Fetching vehicle data...');
    const vehicleData = await processor.fetchVehicleData();
    
    console.log('\n=== Vehicle Data Test Results ===');
    console.log('Total vehicles found:', vehicleData.length);
    
    if (vehicleData.length > 0) {
      const sample = vehicleData[0];
      console.log('\nSample Vehicle Data:');
      console.log({
        trainId: sample.ID,
        line: sample.TRAIN_LINE,
        direction: sample.DIRECTION,
        nextStop: sample.NEXT_STOP,
        location: {
          latitude: sample.LATITUDE,
          longitude: sample.LONGITUDE
        },
        lastModified: sample.LAST_MODIFIED
      });
    }

    return vehicleData;
  } catch (error) {
    console.error('Vehicle data fetch failed:', error);
    throw error;
  }
}

// Run test
console.log('=== Running Vehicle Data Test ===\n');
testVehicleDataFetch()
  .then(() => {
    console.log('\nVehicle data test completed successfully');
    process.exit(0);
  })
  .catch(error => {
    console.error('Test failed:', error);
    process.exit(1);
  });
