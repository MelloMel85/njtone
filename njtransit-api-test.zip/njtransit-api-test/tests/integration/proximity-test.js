import { StationProximityService } from '../../src/services/station-proximity-service.js';
import { TrainDocumentProcessor } from '../../src/processors/trainProcessor.js';
import { AlertService } from '../../src/services/alertService.js';

async function testProximityService() {
  console.log('=== Testing Station Proximity Service ===\n');

  // Create required services
  const trainProcessor = new TrainDocumentProcessor();
  const alertService = new AlertService();
  const proximityService = new StationProximityService(trainProcessor, alertService);

  try {
    // Test Case 1: Find stations near NY Penn
    console.log('Test Case 1: Stations near NY Penn Station');
    const nyPennLocation = {
      latitude: 40.750046,
      longitude: -73.992358
    };

    const nearbyStations = await proximityService.findNearbyStations(
      nyPennLocation.latitude,
      nyPennLocation.longitude,
      5
    );

    console.log('\nNearby Stations:');
    nearbyStations.forEach(station => {
      console.log(`\n${station.stationInfo.name}:`);
      console.log(`Distance: ${station.stationInfo.distance.toFixed(2)}km`);
      console.log(`Lines: ${station.stationInfo.lines.join(', ')}`);
    });

    // Test Case 2: Specific station details
    console.log('\nTest Case 2: NY Penn Station Details');
    const stationDetails = await proximityService.getStationDetails('NY');
    console.log('\nStation Details:');
    console.log(JSON.stringify(stationDetails, null, 2));

    return {
      success: true,
      nearbyStationsCount: nearbyStations.length,
      stationDetailsValid: Boolean(stationDetails.stationInfo)
    };

  } catch (error) {
    console.error('Proximity service test failed:', error);
    throw error;
  }
}

// Run the test
testProximityService()
  .then(results => {
    console.log('\nTest Results:', results);
    console.log('\nProximity service tests completed successfully');
    process.exit(0);
  })
  .catch(error => {
    console.error('Tests failed:', error);
    process.exit(1);
  });
