import { TokenManager } from '../services/tokenManager.js';
import { CONFIG } from '../config/config.js';
import fetch from 'node-fetch';

export class TrainDocumentProcessor {
  constructor(onDocumentUpdate, onError) {
    this.tokenManager = new TokenManager();
    this.pollInterval = null;
    this.onDocumentUpdate = onDocumentUpdate || this.defaultDataCallback;
    this.onError = onError || this.defaultErrorCallback;
    this.lastUpdateTime = null;
  }

  defaultDataCallback(data) {
    console.log('Data received:', {
      timestamp: new Date().toISOString(),
      trainsCount: data?.trains?.length || 0,
      stationsCount: data?.stations?.length || 0
    });
  }

  defaultErrorCallback(error) {
    console.error('Processing error:', error);
  }

  async fetchVehicleData() {
    const token = await this.tokenManager.getValidToken();
    
    const formData = new URLSearchParams();
    formData.append('token', token);

    const response = await fetch(CONFIG.api.vehicleUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: formData
    });

    if (!response.ok) {
      throw new Error(`Vehicle data fetch failed! Status: ${response.status}`);
    }

    return await response.json();
  }

  async fetchStationSchedule(stationCode) {
    const token = await this.tokenManager.getValidToken();
    
    const formData = new URLSearchParams();
    formData.append('token', token);
    formData.append('station', stationCode);
    formData.append('line', '');

    const response = await fetch(CONFIG.api.scheduleUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: formData
    });

    if (!response.ok) {
      throw new Error(`Schedule fetch failed! Status: ${response.status}`);
    }
    
    return await response.json();
  }

  async fetchTrainStops(trainId) {
    const token = await this.tokenManager.getValidToken();
    
    const formData = new URLSearchParams();
    formData.append('token', token);
    formData.append('train', trainId);

    const response = await fetch(CONFIG.api.stopListUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: formData
    });

    if (!response.ok) {
      throw new Error(`Stop list fetch failed! Status: ${response.status}`);
    }

    return await response.json();
  }

  processVehicleData(vehicleData) {
    return vehicleData.map(vehicle => ({
      trainId: vehicle.ID,
      line: vehicle.TRAIN_LINE,
      currentStatus: {
        location: {
          latitude: parseFloat(vehicle.LATITUDE),
          longitude: parseFloat(vehicle.LONGITUDE),
          lastUpdate: vehicle.LAST_MODIFIED
        },
        movement: {
          direction: vehicle.DIRECTION,
          nextStop: vehicle.NEXT_STOP,
          delay: parseInt(vehicle.SEC_LATE, 10) || 0
        }
      }
    }));
  }

  processScheduleData(scheduleData) {
    if (!scheduleData?.ITEMS) return [];

    return scheduleData.ITEMS.map(train => ({
      trainId: train.TRAIN_ID,
      destination: train.DESTINATION,
      scheduledDeparture: train.SCHED_DEP_DATE,
      track: train.TRACK,
      line: {
        name: train.LINE,
        code: train.LINECODE,
        abbreviation: train.LINEABBREVIATION
      },
      status: {
        current: train.STATUS,
        delay: parseInt(train.SEC_LATE, 10) || 0
      },
      capacity: train.CAPACITY || null
    }));
  }

  processStationData(stationData) {
    if (!stationData?.ITEMS) return [];

    return stationData.ITEMS.map(station => ({
      name: station.STATIONNAME,
      code: station.STATION_CODE,
      line: station.LINE,
      location: {
        latitude: parseFloat(station.LATITUDE),
        longitude: parseFloat(station.LONGITUDE)
      },
      accessibility: station.ADA_ACCESSIBLE === '1',
      schedule: this.processScheduleData(station)
    }));
  }

  async pollSystemData() {
    try {
      const [vehicleData, stationData] = await Promise.all([
        this.fetchVehicleData(),
        this.fetchStationSchedule('NP') // Example station code
      ]);

      const trains = this.processVehicleData(vehicleData);
      const stations = this.processStationData(stationData);

      this.onDocumentUpdate({ timestamp: new Date().toISOString(), trains, stations });
    } catch (error) {
      this.onError(error);
    }
  }

  async start() {
    if (this.pollInterval) {
      console.warn('Polling already started');
      return;
    }

    await this.pollSystemData();
    this.pollInterval = setInterval(
      () => this.pollSystemData(),
      CONFIG.polling.intervalSeconds * 1000
    );

    console.log(`Processing started with ${CONFIG.polling.intervalSeconds} second interval`);
  }

  stop() {
    if (this.pollInterval) {
      clearInterval(this.pollInterval);
      this.pollInterval = null;
      console.log('Processing stopped');
    }
  }
}