export const CONFIG = {
  auth: {
    tokenUrl: 'https://testraildata.njtransit.com/api/TrainData/getToken',
    username: 'NJTAPPDroid2023',
    password: '$andMan3285@',
    tokenExpirationHours: 2
  },
  api: {
    scheduleUrl: 'https://testraildata.njtransit.com/api/TrainData/getTrainSchedule19Rec',
    vehicleUrl: 'https://testraildata.njtransit.com/api/TrainData/getVehicleData',
    stopListUrl: 'https://testraildata.njtransit.com/api/TrainData/getTrainStopList',
    alertsUrl: 'https://content.njtransit.com/NJTRailAlertsAndAdvisories-feed.json'
  },
  polling: {
    intervalSeconds: 15,
    retryDelaySeconds: 5
  }
};

// Train line definitions
export const TRAIN_LINES = {
  'AC': { name: 'Atlantic City Line', color: '#2E55A5' },
  'BC': { name: 'Bergen County Line', color: '#98A8BF' },
  'GS': { name: 'Gladstone Branch', color: '#A1D5AE' },
  'MC': { name: 'MontClair-Boonton Line', color: '#C36366' },
  'ME': { name: 'ME Line', color: '#00953B' },
  'ML': { name: 'Main Line', color: '#F2B826' },
  'NC': { name: 'North Jersey Coast Line', color: '#009CDB' },
  'NE': { name: 'Northeast Corridor Line', color: '#F7505E' },
  'PR': { name: 'Princeton Branch', color: '#F7505E' },
  'PV': { name: 'Pascack Valley Line', color: '#A34F8B' },
  'RV': { name: 'Raritan Valley Line', color: '#FF993E' }
};
