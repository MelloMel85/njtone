import { STATIONS } from './stationData.js';

export class LocationService {
  constructor() {
    this.stations = STATIONS;
  }

  // Rest of the class implementation remains the same
  toRadians(degrees) {
    return degrees * (Math.PI / 180);
  }

  calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // Earth's radius in kilometers
    const dLat = this.toRadians(lat2 - lat1);
    const dLon = this.toRadians(lon2 - lon1);
    
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(this.toRadians(lat1)) * Math.cos(this.toRadians(lat2)) * 
              Math.sin(dLon/2) * Math.sin(dLon/2);
    
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  }

  findStationsInRadius(latitude, longitude, radius) {
    const nearbyStations = [];

    for (const station of this.stations) {
      try {
        const stationLat = parseFloat(station.LATITUTE);
        const stationLon = parseFloat(station.LONGITUDE);
        
        const distance = this.calculateDistance(
          latitude,
          longitude,
          stationLat,
          stationLon
        );

        if (distance <= radius) {
          nearbyStations.push({
            ...station,
            distance: distance
          });
        }
      } catch (error) {
        console.error(`Error processing station ${station.STATIONNAME}:`, error);
      }
    }

    return nearbyStations.sort((a, b) => a.distance - b.distance);
  }

  async getStationDetails(stationCode, trainProcessor, alertService) {
    try {
      const scheduleData = await trainProcessor.fetchStationSchedule(stationCode);
      const alerts = await alertService.getAlertsForStation(stationCode);

      return {
        stationInfo: this.stations.find(s => s.PENTA_ID === stationCode),
        schedule: scheduleData,
        alerts: alerts
      };
    } catch (error) {
      console.error(`Error getting details for station ${stationCode}:`, error);
      throw error;
    }
  }
}