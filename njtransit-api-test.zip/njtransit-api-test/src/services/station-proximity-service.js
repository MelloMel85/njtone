import { CONFIG } from '../config/config.js';

import { STATIONS } from './stationData.js';

class StationProximityService {
  constructor(trainProcessor, alertService) {
    this.stations = STATIONS;  // Now properly initialized as an array
    this.trainProcessor = trainProcessor;
    this.alertService = alertService;
    this.cachedResults = new Map();
    this.cacheTimeout = 30000; // 30 seconds cache
  }

  // Calculate distance using Haversine formula
  calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // Earth's radius in km
    
    // Convert to radians
    const toRad = x => x * (Math.PI / 180);
    const lat1Rad = toRad(lat1);
    const lon1Rad = toRad(lon1);
    const lat2Rad = toRad(lat2);
    const lon2Rad = toRad(lon2);

    // Haversine formula
    const dlon = lon2Rad - lon1Rad;
    const dlat = lat2Rad - lat1Rad;
    const a = Math.sin(dlat/2) ** 2 + 
              Math.cos(lat1Rad) * Math.cos(lat2Rad) * 
              Math.sin(dlon/2) ** 2;
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    
    return R * c; // Distance in kilometers
  }

  async findNearbyStations(latitude, longitude, radius) {
    console.log(`Searching for stations near (${latitude}, ${longitude}) within ${radius}km`);
    console.log(`Total stations in database: ${this.stations.length}`);

    const nearbyStations = [];

    for (const station of this.stations) {
      try {
        const stationLat = parseFloat(station.LATITUTE);
        const stationLon = parseFloat(station.LONGITUDE);

        // Calculate distance
        const distance = this.calculateDistance(
          latitude,
          longitude,
          stationLat,
          stationLon
        );

        console.log(`Calculated distance to ${station.STATIONNAME}: ${distance.toFixed(2)}km`);

        if (distance <= radius) {
          nearbyStations.push({
            stationInfo: {
              name: station.STATIONNAME,
              code: station.PENTA_ID,
              distance: distance,
              location: {
                latitude: stationLat,
                longitude: stationLon
              },
              accessibility: station.ADA_ACCESSIBLE === "1",
              lines: station.LINE.split(';').map(line => line.trim())
            }
          });
        }
      } catch (error) {
        console.error(`Error processing station ${station.STATIONNAME}:`, error);
      }
    }

    // Sort by distance
    const sortedStations = nearbyStations.sort((a, b) => 
      a.stationInfo.distance - b.stationInfo.distance
    );

    console.log(`Found ${sortedStations.length} stations within ${radius}km`);
    return sortedStations;
  }

  async getStationDetails(stationId) {
    const station = this.stations.find(s => s.PENTA_ID === stationId);
    if (!station) {
      throw new Error(`Station not found: ${stationId}`);
    }

    return {
      stationInfo: {
        name: station.STATIONNAME,
        code: station.PENTA_ID,
        location: {
          latitude: parseFloat(station.LATITUTE),
          longitude: parseFloat(station.LONGITUDE)
        },
        accessibility: station.ADA_ACCESSIBLE === "1",
        lines: station.LINE.split(';').map(line => line.trim())
      }
    };
  }
}

export { StationProximityService };
