import fetch from 'node-fetch';
import { CONFIG } from '../config/config.js';

export class AlertService {
  constructor() {
    this.alerts = [];
    this.lastUpdate = null;
  }

  async fetchAlerts() {
    try {
      const response = await fetch(CONFIG.api.alertsUrl);
      if (!response.ok) {
        throw new Error(`Failed to fetch alerts: ${response.status}`);
      }

      const alertData = await response.json();
      this.alerts = this.processAlerts(alertData.items || alertData);
      this.lastUpdate = new Date();
      
      return this.alerts;
    } catch (error) {
      console.error('Error fetching alerts:', error);
      throw error;
    }
  }

  processAlerts(alertData) {
    return (Array.isArray(alertData) ? alertData : []).map(alert => ({
      id: this.generateAlertId(alert),
      title: alert.title,
      description: alert.description,
      pubDate: new Date(alert.pubDate),
      category: alert.category || 'General',
      affectedLines: this.parseAffectedLines(alert.title, alert.description),
      affectedStations: this.parseAffectedStations(alert.title, alert.description),
      type: this.categorizeAlert(alert.title, alert.description),
      severity: this.determineSeverity(alert.title, alert.description)
    }));
  }

  generateAlertId(alert) {
    // Implement your own alert ID generation logic
    return `${alert.title}-${alert.pubDate}`;
  }

  parseAffectedLines(title, description) {
    // Implement your logic to parse affected lines from the alert data
    return [];
  }

  parseAffectedStations(title, description) {
    // Implement your logic to parse affected stations from the alert data
    return [];
  }

  categorizeAlert(title, description) {
    // Implement your logic to categorize the alert type
    return 'General';
  }

  determineSeverity(title, description) {
    // Implement your logic to determine the alert severity
    return 'Medium';
  }

  getActiveAlerts() {
    const cutoff = new Date(Date.now() - 24 * 60 * 60 * 1000);
    return this.alerts.filter(alert => alert.pubDate > cutoff);
  }

  getAlertsForLine(lineCode) {
    return this.alerts.filter(alert => 
      alert.affectedLines.includes(lineCode)
    );
  }

  getAlertsForStation(stationCode) {
    return this.alerts.filter(alert => 
      alert.affectedStations.includes(stationCode)
    );
  }
}