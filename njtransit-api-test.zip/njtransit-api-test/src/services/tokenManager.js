import { CONFIG } from '../config/config.js';
import fetch from 'node-fetch';

export class TokenManager {
  constructor() {
    this.token = null;
    this.tokenExpiration = null;
  }

  isTokenValid() {
    if (!this.token || !this.tokenExpiration) {
      return false;
    }
    // Add 5 minute buffer before expiration
    const bufferMs = 5 * 60 * 1000;
    return new Date().getTime() < (this.tokenExpiration.getTime() - bufferMs);
  }

  async getValidToken() {
    if (this.isTokenValid()) {
      return this.token;
    }

    try {
      const formData = new URLSearchParams();
      formData.append('username', CONFIG.auth.username);
      formData.append('password', CONFIG.auth.password);

      const response = await fetch(CONFIG.auth.tokenUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: formData
      });

      if (!response.ok) {
        throw new Error(`Authentication failed! Status: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.errorMessage?.includes('Daily usage limit')) {
        throw new Error(data.errorMessage);
      }

      if (data.Authenticated === "False") {
        throw new Error('Authentication failed: Invalid credentials');
      }

      this.token = data.UserToken;
      this.tokenExpiration = new Date(new Date().getTime() + (CONFIG.auth.tokenExpirationHours * 60 * 60 * 1000));
      
      return this.token;
    } catch (error) {
      console.error('Token acquisition failed:', error);
      throw error;
    }
  }
}
