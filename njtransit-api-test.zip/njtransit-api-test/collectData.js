import { TrainDocumentProcessor } from './src/processors/trainProcessor.js';
import { AlertService } from './src/services/alertService.js';
import { StationProximityService } from './src/services/station-proximity-service.js';
import { LocationService } from './src/services/locationService.js';
import { STATIONS } from './src/services/stationData.js';
import fs from 'fs/promises';

class DataCollector {
    constructor() {
        this.trainProcessor = new TrainDocumentProcessor();
        this.alertService = new AlertService();
        this.locationService = new LocationService();
        this.proximityService = new StationProximityService(this.trainProcessor, this.alertService);
    }

    async collectAllStationData() {
        console.log('Starting data collection for all stations...');
        const results = {
            timestamp: new Date().toISOString(),
            stationCount: STATIONS.length,
            stations: []
        };

        for (const station of STATIONS) {
            try {
                console.log(`Collecting data for ${station.STATIONNAME}...`);
                
                // Get schedule data
                const scheduleData = await this.trainProcessor.fetchStationSchedule(station.PENTA_ID);
                
                // Get alerts
                const alerts = await this.alertService.getAlertsForStation(station.PENTA_ID);
                
                // Get nearby stations (within 5km)
                const nearbyStations = await this.proximityService.findNearbyStations(
                    parseFloat(station.LATITUTE),
                    parseFloat(station.LONGITUDE),
                    5
                );

                // Collect station data
                const stationData = {
                    stationInfo: {
                        name: station.STATIONNAME,
                        id: station.PENTA_ID,
                        location: {
                            latitude: station.LATITUTE,
                            longitude: station.LONGITUDE
                        },
                        line: station.LINE,
                        accessible: station.ADA_ACCESSIBLE === "1"
                    },
                    schedule: scheduleData,
                    alerts: alerts,
                    nearbyStations: nearbyStations.map(nearby => ({
                        name: nearby.stationInfo.name,
                        distance: nearby.stationInfo.distance
                    }))
                };

                results.stations.push(stationData);

                // Add delay to avoid hitting rate limits
                await new Promise(resolve => setTimeout(resolve, 1000));

            } catch (error) {
                console.error(`Error collecting data for ${station.STATIONNAME}:`, error);
                results.stations.push({
                    stationInfo: {
                        name: station.STATIONNAME,
                        id: station.PENTA_ID,
                        error: error.message
                    }
                });
            }
        }

        return results;
    }

    async collectTrainData() {
        try {
            console.log('Collecting vehicle data...');
            const vehicleData = await this.trainProcessor.fetchVehicleData();
            
            return {
                timestamp: new Date().toISOString(),
                trainCount: vehicleData.length,
                trains: vehicleData
            };
        } catch (error) {
            console.error('Error collecting train data:', error);
            throw error;
        }
    }

    async saveResults(data, filename) {
        try {
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const fullFilename = `${filename}-${timestamp}.json`;
            
            await fs.writeFile(
                fullFilename,
                JSON.stringify(data, null, 2),
                'utf8'
            );
            
            console.log(`Data saved to ${fullFilename}`);
            
        } catch (error) {
            console.error('Error saving results:', error);
            throw error;
        }
    }
}

// Run the data collection
async function main() {
    const collector = new DataCollector();
    const outputDir = './data';

    try {
        // Create output directory if it doesn't exist
        await fs.mkdir(outputDir, { recursive: true });
        
        // Collect and save station data
        console.log('Starting station data collection...');
        const stationData = await collector.collectAllStationData();
        await collector.saveResults(stationData, `${outputDir}/station-data`);
        
        // Collect and save train data
        console.log('Starting train data collection...');
        const trainData = await collector.collectTrainData();
        await collector.saveResults(trainData, `${outputDir}/train-data`);
        
        console.log('Data collection completed successfully!');
        
    } catch (error) {
        console.error('Data collection failed:', error);
        process.exit(1);
    }
}

// Run the script
main();
