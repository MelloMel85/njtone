import { TrainDocumentProcessor } from './src/processors/trainProcessor.js';
import { AlertService } from './src/services/alertService.js';
import { StationProximityService } from './src/services/station-proximity-service.js';
import { LocationService } from './src/services/locationService.js';
import fs from 'fs/promises';

class LocationBasedCollector {
    constructor() {
        this.trainProcessor = new TrainDocumentProcessor();
        this.alertService = new AlertService();
        this.locationService = new LocationService();
        this.proximityService = new StationProximityService(this.trainProcessor, this.alertService);
    }

    async collectLocationData(latitude, longitude, radiusKm) {
        console.log(`\nCollecting data for location: ${latitude}, ${longitude} (${radiusKm}km radius)`);
        
        try {
            // Find nearby stations
            console.log('\nFinding nearby stations...');
            const nearbyStations = await this.proximityService.findNearbyStations(
                latitude,
                longitude,
                radiusKm
            );

            console.log(`Found ${nearbyStations.length} stations within ${radiusKm}km`);

            // Collect detailed data for each nearby station
            const stationDetails = [];
            for (const station of nearbyStations) {
                console.log(`\nCollecting data for ${station.stationInfo.name}...`);
                
                try {
                    // Get schedule data
                    const scheduleData = await this.trainProcessor.fetchStationSchedule(station.stationInfo.code);
                    
                    // Get alerts
                    const alerts = await this.alertService.getAlertsForStation(station.stationInfo.code);
                    
                    // Enhance station data with additional information
                    stationDetails.push({
                        station: {
                            ...station.stationInfo,
                            facilities: {
                                hasParking: true,
                                isAccessible: station.stationInfo.accessibility,
                                hasTicketVendingMachines: true,
                                hasWaitingArea: true,
                                hasBikeRacks: false,
                                hasRestrooms: true
                            },
                            connections: {
                                busLines: this.getBusConnections(station.stationInfo.name),
                                hasPathTrains: station.stationInfo.name.includes("Penn") || 
                                             station.stationInfo.name.includes("Hoboken"),
                                hasLightRail: this.hasLightRail(station.stationInfo.name)
                            }
                        },
                        distance: station.stationInfo.distance,
                        schedule: {
                            upcomingTrains: scheduleData.ITEMS?.map(train => ({
                                trainId: train.TRAIN_ID,
                                destination: train.DESTINATION,
                                scheduledDeparture: train.SCHED_DEP_DATE,
                                status: train.STATUS,
                                track: train.TRACK,
                                line: train.LINE,
                                delay: parseInt(train.SEC_LATE, 10) || 0,
                                capacity: train.CAPACITY
                            })) || [],
                            messages: [
                                ...scheduleData.STATIONMSGS?.map(msg => ({
                                    type: msg.MSG_TYPE,
                                    text: msg.MSG_TEXT,
                                    timestamp: msg.MSG_PUBDATE
                                })) || [],
                                ...alerts.map(alert => ({
                                    type: 'ALERT',
                                    text: alert.title,
                                    timestamp: alert.pubDate
                                }))
                            ]
                        },
                        weather: await this.getWeatherInfo(
                            station.stationInfo.latitude, 
                            station.stationInfo.longitude
                        )
                    });

                    // Add small delay between requests
                    await new Promise(resolve => setTimeout(resolve, 1000));
                } catch (error) {
                    console.error(`Error collecting data for ${station.stationInfo.name}:`, error);
                }
            }

            // Get all active trains
            console.log('\nCollecting active train data...');
            const allTrains = await this.trainProcessor.fetchVehicleData();
            
            // Filter for trains near our location
            const nearbyTrains = allTrains.filter(train => {
                const trainLat = parseFloat(train.LATITUDE);
                const trainLon = parseFloat(train.LONGITUDE);
                
                if (!trainLat || !trainLon) return false;
                
                const distance = this.locationService.calculateDistance(
                    latitude,
                    longitude,
                    trainLat,
                    trainLon
                );
                
                return distance <= radiusKm;
            });

            // Compile results
            const results = {
                searchParameters: {
                    latitude,
                    longitude,
                    radiusKm,
                    timestamp: new Date().toISOString()
                },
                nearbyStations: stationDetails,
                nearbyTrains: nearbyTrains.map(train => ({
                    trainId: train.ID,
                    line: train.TRAIN_LINE,
                    nextStop: train.NEXT_STOP,
                    location: {
                        latitude: train.LATITUDE,
                        longitude: train.LONGITUDE
                    },
                    status: {
                        direction: train.DIRECTION,
                        secondsLate: parseInt(train.SEC_LATE, 10) || 0,
                        lastUpdated: train.LAST_MODIFIED
                    }
                }))
            };

            // Save results
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const filename = `./data/location-data-${timestamp}.json`;
            
            await fs.mkdir('./data', { recursive: true });
            await fs.writeFile(filename, JSON.stringify(results, null, 2));
            
            console.log(`\nData collection completed and saved to ${filename}`);
            
            // Print summary
            this.printSummary(results);
            
            return results;

        } catch (error) {
            console.error('Error during data collection:', error);
            throw error;
        }
    }

    printSummary(results) {
        console.log('\nSummary:');
        console.log(`- Found ${results.nearbyStations.length} nearby stations`);
        console.log(`- Found ${results.nearbyTrains.length} active trains in the area`);
        
        console.log('\nClosest stations:');
        results.nearbyStations
            .sort((a, b) => a.distance - b.distance)
            .slice(0, 5)
            .forEach(station => {
                console.log(`- ${station.station.name} (${station.distance.toFixed(2)}km)`);
                
                const nextTrain = station.schedule.upcomingTrains[0];
                if (nextTrain) {
                    console.log(`  Next train: ${nextTrain.trainId} to ${nextTrain.destination} at ${nextTrain.scheduledDeparture}`);
                }
                
                if (station.schedule.messages.length > 0) {
                    console.log(`  ⚠️ Has ${station.schedule.messages.length} active alerts`);
                }
            });
    }

    getBusConnections(stationName) {
        // This would ideally come from a database or API
        const busConnections = {
            "Newark Penn Station": ["1", "5", "21", "25", "34", "40"],
            "Secaucus Junction": ["2", "78", "85"],
            "Newark Broad Street": ["11", "28", "29"],
            // Add more stations as needed
        };
        return busConnections[stationName] || [];
    }

    hasLightRail(stationName) {
        // This would ideally come from a database
        const lightRailStations = [
            "Newark Penn Station",
            "Newark Broad Street",
            "Hoboken Terminal"
        ];
        return lightRailStations.includes(stationName);
    }

    async getWeatherInfo(lat, lon) {
        // This would normally call a weather API
        return {
            temperature: 72,
            condition: "Partly Cloudy",
            precipitation: 0
        };
    }
}

// Get command line arguments or use defaults
const args = process.argv.slice(2);
const latitude = parseFloat(args[0]) || 40.750046;  // Default to NY Penn Station
const longitude = parseFloat(args[1]) || -73.992358;
const radiusKm = parseFloat(args[2]) || 5;

// Run the collection
const collector = new LocationBasedCollector();
collector.collectLocationData(latitude, longitude, radiusKm)
    .catch(error => {
        console.error('Collection failed:', error);
        process.exit(1);
    });
